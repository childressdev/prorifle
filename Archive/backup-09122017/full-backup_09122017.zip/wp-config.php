<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'devchild_prorifle');

/** MySQL database username */
define('DB_USER', 'devchild_admin');

/** MySQL database password */
define('DB_PASSWORD', 'GHW5*e$4F]po');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'apl4N@)5#-uAY3|r=33>yyEt&Z[>{xP?/xo)RTh ![@x=e:ejC,2vO[ZUD-&4m7>');
define('SECURE_AUTH_KEY',  '|s9VhO%`06s %H)&fc8vkx/La+/SUz4WFD3LF+EyX4n*JTB^`BYRi MlM+s)@Wy-');
define('LOGGED_IN_KEY',    '2wBy1@Hs&e-dn`$mrr#x[nb0h%~P)XP|3F-4,UE+8`G<_: Pw!YfEu+ItQN.j+4p');
define('NONCE_KEY',        'AO/JmAPW58p8 2evnd(_B#+yO`B/,R+=x|*4zlJn_Byx<Z|AraA--G91B,2` B| ');
define('AUTH_SALT',        'xz-II37X}m9+$z>Sl!X1#17gE.Z@@x={rD}N-;tpWs}0@Bh|aUUt&{#${E)9d%-O');
define('SECURE_AUTH_SALT', '|KDB1B:![|4fNgd]&kQ,q[1@G0%kF-t N<V?#z58FF-b[Q@-+<udA5I(j59DaBR[');
define('LOGGED_IN_SALT',   'g0o^4M%X.U}#U|Q@nSmN*&&az#|KG++$QW-tmQjU_hJ8bOUZs9|W|Q|+kT/8i.9p');
define('NONCE_SALT',       '-1/+=IIMY{F2?$kllu;M8h_1I|Z*Yml++MNHx2z+/P3xQ%-NnSL/lp$ EB)#,N1Y');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
